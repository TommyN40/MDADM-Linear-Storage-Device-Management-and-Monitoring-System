#include <stdlib.h> 
#include <string.h> 
#include <stdio.h> 
#include "cache.h" 
#include "jbod.h" 

static cache_entry_t *cache = NULL; 
static int cache_size = 0; 
static int clock = 0; 
static int num_queries = 0; 
static int num_hits = 0; 
int isCreated = 0; 

int cache_create(int num_entries) { 
    int toReturn = 0; 
    if (isCreated == 1 || num_entries < 2 || num_entries > 4096) { 
        toReturn = -1; 
    } else { 
        cache = calloc(num_entries, sizeof(cache_entry_t)); 
        cache_size = num_entries; 
        isCreated = 1; 
        toReturn = 1; 
    } 

    return toReturn; 

} 

int cache_destroy(void) { 
    int toReturn = 0; 
    if (isCreated == 0) { 
        toReturn = -1; 
    } else { 
        free(cache); 
        cache = NULL; 
        cache_size = 0; 
        isCreated = 0; 
        toReturn = 1; 

    } 

    return toReturn; 

} 

 

int cache_lookup(int disk_num, int block_num, uint8_t *buf) { 
    int toReturn = 0; 
    int found = 0; 

    if (isCreated == 0 || buf == NULL || disk_num < 0 || block_num < 0 || disk_num > 16 || block_num > 256) { 

        toReturn = -1; 

    } else { 
        for (int i = 0; i < cache_size; i++) { 
            if (cache[i].valid == 1 && cache[i].disk_num == disk_num && cache[i].block_num == block_num) { 
                memcpy(buf, cache[i].block, 256); 
                clock++; 
                cache[i].access_time = clock; 
                toReturn = 1; 
                found = 1; 
                break; 
            } 
        } 
        if (!found) { 
            toReturn = -1; 
        } 
    } 

    return toReturn; 
} 

 
void cache_update(int disk_num, int block_num, const uint8_t *buf) { 

    for (int i = 0; i < cache_size; i++) { 
        if (cache[i].valid == 1 && cache[i].disk_num == disk_num && cache[i].block_num == block_num) { 
            memcpy(cache[i].block, buf, 256); 
            clock++; 
            cache[i].access_time = clock; 
            num_hits++; 
            break; 
        } 

    } 

} 

int cache_insert(int disk_num, int block_num, const uint8_t *buf) { 
    int toReturn = 0; 
    if (isCreated == 0 || buf == NULL || disk_num < 0 || block_num < 0 || disk_num > 16 || block_num > 256) { 
        toReturn = -1; 
    } else { 
        int found = 0; 
        int emptyIndex = -1; 
        for (int i = 0; i < cache_size; i++) { 
            if (cache[i].valid == 1 && cache[i].disk_num == disk_num && cache[i].block_num == block_num) {
	      
                toReturn = -1; 
                found = 1; 
                break; 

            } else if (cache[i].valid == 0 && emptyIndex == -1) { 
                emptyIndex = i;
            } 
        } 
        if (!found) { 
            if (emptyIndex != -1) { 
    
                cache[emptyIndex].valid = 1; 
                cache[emptyIndex].disk_num = disk_num; 
                cache[emptyIndex].block_num = block_num;
                clock++; 

                cache[emptyIndex].access_time = clock; 
                memcpy(cache[emptyIndex].block, buf, 256); 

                toReturn = 1; 

            } else { 

                int lowestIndex = 0; 
                int lowestAccs = cache[0].access_time; 

                for (int j = 1; j < cache_size; j++) { 
                   if (cache[j].access_time < lowestAccs) { 
                        lowestIndex = j; 
                        lowestAccs = cache[j].access_time; 
                    } 

                } 
                cache[lowestIndex].valid = 1; 
                cache[lowestIndex].disk_num = disk_num; 
                cache[lowestIndex].block_num = block_num; 

                clock++; 
                cache[lowestIndex].access_time = clock; 
                memcpy(cache[lowestIndex].block, buf, 256); 

                toReturn = 1; 
            } 

        } 

    } 

    return toReturn; 

} 

 

bool cache_enabled(void) { 
  return false; 

} 

 

void cache_print_hit_rate(void) { 
  fprintf(stderr, "Hit rate: %5.1f%%\n", 100 * (float) num_hits / num_queries); 

}  
