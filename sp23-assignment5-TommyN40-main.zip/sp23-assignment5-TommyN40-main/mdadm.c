//Tommy Nguyen
	#include <stdio.h> 
	#include <string.h> 
	#include <assert.h> 
	#include "mdadm.h" 
	#include "jbod.h" 
	
	int mounted = 0;
	uint32_t generate_opcode(jbod_cmd_t cmd, int disk_num, int reserve, int block_num) {
	  disk_num = disk_num << 22;
	  cmd = cmd << 26;
	  reserve = reserve << 8;
	  return disk_num | block_num | cmd | reserve;
	
	}
	 
	int mdadm_mount(void) {
	  if (mounted == 1) {
	   
	    return -1;
	
	  }
	
	  uint32_t op = generate_opcode(JBOD_MOUNT, 0, 0, 0);
	  jbod_operation(op, NULL);
	  mounted = 1;
	  return 1;
	
	}
	
	int mdadm_unmount(void) {
	  if (mounted == 0) {
	   
	    return -1;
	   
	  }
	  uint32_t op = generate_opcode(JBOD_UNMOUNT, 0, 0, 0);
	  jbod_operation(op, NULL);
	  mounted = 0;
	  return 1;
	}
	
	
	int mdadm_read(uint32_t addr, uint32_t len, uint8_t *buf) {  
	  if (!mounted || len > 1024 || (len && buf == NULL) || addr + len >= (JBOD_NUM_DISKS * JBOD_DISK_SIZE)) {
	
	    return -1;
	   
	  }
	  int read_bytes = 0;
	  int current_addr = addr;
	 
	  while (read_bytes < len) {
	    uint8_t temp_buff[256];
	
	    int block_num = (current_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
	    int disk_num = current_addr / JBOD_DISK_SIZE;
	
	    uint32_t op_seek_disk = generate_opcode(JBOD_SEEK_TO_DISK, disk_num, 0, block_num);
	    uint32_t op_seek_block = generate_opcode(JBOD_SEEK_TO_BLOCK, 0, 0, block_num);
	
	    jbod_operation(op_seek_disk, NULL);
	    jbod_operation(op_seek_block, NULL);
	
	    int offset = current_addr % 256;
	   
	    uint32_t op_read_block = generate_opcode(JBOD_READ_BLOCK, 0, 0, 0);
	
	    jbod_operation(op_read_block, temp_buff);
	
	    int available_bytes = 256 - offset;
	    int bytes_to_read = len - read_bytes;
	    int bytes_read = (available_bytes < bytes_to_read) ? available_bytes : bytes_to_read;
	
	    memcpy(buf + read_bytes, temp_buff + offset, bytes_read);
	    read_bytes += bytes_read;
	    current_addr += bytes_read;    
	
	  }
	  return len;
	}
	
	int mdadm_write(uint32_t addr, uint32_t len, const uint8_t *buf) {
	    int written_bytes = 0;
	    int current_addr = addr;
	    int offset = 0;
	
	    if (len == 0 && buf == NULL) {
	        return 0;
	    }
	    if (!mounted || len > 1024 || addr + len > JBOD_NUM_DISKS * JBOD_DISK_SIZE) {
	        return -1;
	    }
	    if (buf == NULL && len > 0) {
	        return -1;
	    }
	
	    while (written_bytes < len) {
	        uint8_t temp_buff[JBOD_BLOCK_SIZE];
	        int block_id = (current_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
	        int disk_id = current_addr / JBOD_DISK_SIZE;
	
	        uint32_t op_seek_disk = generate_opcode(JBOD_SEEK_TO_DISK, disk_id, 0, block_id);
	        uint32_t op_seek_block = generate_opcode(JBOD_SEEK_TO_BLOCK, 0, 0, block_id);
	
	        jbod_operation(op_seek_disk, NULL);
	        jbod_operation(op_seek_block, NULL);
	
	        offset = current_addr % JBOD_BLOCK_SIZE;
	        uint32_t op_read_block = generate_opcode(JBOD_READ_BLOCK, 0, 0, 0);
	        jbod_operation(op_read_block, temp_buff);
	
	        int available_bytes = JBOD_BLOCK_SIZE - offset;
	        int bytes_to_write = len - written_bytes;
	        int bytes_written = (available_bytes < bytes_to_write) ? available_bytes : bytes_to_write;
	
	        memcpy(temp_buff + offset, buf + written_bytes, bytes_written);
	
	        jbod_operation(op_seek_disk, NULL);
	        jbod_operation(op_seek_block, NULL);
	
	        uint32_t op_write_block = generate_opcode(JBOD_WRITE_BLOCK, 0, 0, 0);
	        jbod_operation(op_write_block, temp_buff);
	
	        written_bytes += bytes_written;
	        current_addr += bytes_written;
	    }
	    return len;
	}
