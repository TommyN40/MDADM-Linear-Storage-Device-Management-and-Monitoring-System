#include <stdbool.h> 
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <stdio.h> 
#include <errno.h> 
#include <err.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <arpa/inet.h> 
#include "jbod.h" 

/* the client socket descriptor for the connection to the server */
int cli_sd = -1; 

/* attempts to read n bytes from fd; returns true on success and false on * failure */
static bool nread(int fd, int len, uint8_t *buf) { 
  ssize_t n = read(fd, buf, len); 
  if (n == -1) { 
    perror("read"); 
    return false; 
  } 
  return n == len; 
} 

/* attempts to write n bbytes to fd; returns true on success and false on * failure */
static bool nwrite(int fd, int len, uint8_t *buf) { 
  ssize_t n = write(fd, buf, len); 
  if (n == -1) { 
    perror("write"); 
    return false; 
  } 
  return n == len; 
} 

/* attempts to receive a packet from fd; returns true on success and false on * failure */
static bool recv_packet(int fd, uint32_t *op, uint16_t *ret, uint8_t *block) { 
  uint32_t net_op; 
  uint16_t net_ret; 
  if (!nread(fd, sizeof(net_op), (uint8_t*)&net_op)) return false; 
  *op = ntohl(net_op); 
  if (!nread(fd, sizeof(net_ret), (uint8_t*)&net_ret)) return false; 
  *ret = ntohs(net_ret); 
  if (!nread(fd, JBOD_BLOCK_SIZE, block)) return false; 
  return true; 
} 

/* attempts to send a packet to sd; returns success and false on * failure */
static bool send_packet(int sd, uint32_t op, uint8_t *block) { 
  uint32_t net_op = htonl(op); 
  if (!nwrite(sd, sizeof(net_op), (uint8_t*)&net_op)) return false; 
  if (!nwrite(sd, JBOD_BLOCK_SIZE, block)) return false; 
  return true; 
} 

 
/* attempts to connect to server and set the global cli_sd varialbe to the * socket; returns true if successful and false if not. */
bool jbod_connect(const char *ip, uint16_t port) { 
  struct sockaddr_in addr; 
  cli_sd = socket(AF_INET, SOCK_STREAM, 0); 
  if (cli_sd == -1) { 
    perror("socket"); 
    return false; 
  } 
  memset(&addr, 0, sizeof(addr)); 
  addr.sin_family = AF_INET; 
  addr.sin_addr.s_addr = inet_addr(ip); 
  addr.sin_port = htons(port); 
  if (connect(cli_sd, (struct sockaddr*)&addr, sizeof(addr)) == -1) { 
    perror("connect"); 
    close(cli_sd); 
    cli_sd = -1; 
    return false; 
  } 
  return true; 
} 

/* disconnects from the serverr and resets cli_sd */
void jbod_disconnect(void) { 
  if (cli_sd != -1) { 
    close(cli_sd); 
    cli_sd = -1; 
  } 
} 

/* send the JBOD operation to the server and receives the processes the * response. */
int jbod_client_operation(uint32_t op, uint8_t *block) {
  uint16_t ret; 
  if (!send_packet(cli_sd, op, block)) { 
    warn("Failed to send packet to server"); 
    return -1; 
  } 
  if (!recv_packet(cli_sd, &op, &ret, block)) { 
    warn("Failed to receive packet from server"); 
    return -1; 
  } 
  return ret; 
} 
